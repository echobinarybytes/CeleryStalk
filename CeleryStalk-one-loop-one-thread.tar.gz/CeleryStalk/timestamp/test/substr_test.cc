#include <string>

int main() {
    std::string str("")
}
